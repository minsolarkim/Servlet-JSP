package com.bc.ajax.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/getIdName")
public class GetIdNameController extends HttpServlet{
	
	//프론트로 안 하고 그냥 ajax요청 받고 처리할 jsp
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");
		//jsp에서는 맨 위에 기본적으로 contentType="text/html; charset=UTF-8" 이게 있어서 해줄 필요 없었다.
		//request.setCharacterEncoding("UTF-8") 아님 주의
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		System.out.println(">>id : " + id + ", pwd : " + pwd);
		
		//(생략)DB 연동해서 회원여부 확인 후 필요데이터 가져오기
		String name = "홍길동";
		
		PrintWriter out = response.getWriter();
		//형태 : {"id":"hong", "name":"홍길동"}
		//Ajax의 약속 "":"" 쌍따옴표 꼭 닫아주기!!!
//		자바에서는 ''못 쓰니까 주의해야 하는 거 
		String result = "{\"id\":\"" + id + "\", \"name\":\""+ name+"\"}";
		out.print(result);
		
	}
	
}
